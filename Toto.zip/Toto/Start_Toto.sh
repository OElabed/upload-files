#!/usr/bin/env bash

i=0

while true; do 
    sleep 5; 
    i=$(($i + 1))
    echo "running Tonton $i"; 
    
done